package edu.wustl.cse.mosaic;

/**
 * @author Dennis Cosgrove (http://www.cse.wustl.edu/~cosgroved/)
 */
enum Mode {
	FILL,
	OUTLINE
}
