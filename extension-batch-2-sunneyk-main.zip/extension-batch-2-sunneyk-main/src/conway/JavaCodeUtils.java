package conway;

import support.cse131.NotYetImplementedException;

public class JavaCodeUtils {
	public static String toJavaCode(Conway conway) {

		// FIXME
		throw new NotYetImplementedException();

	}
}
