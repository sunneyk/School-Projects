package mosaics;


import edu.wustl.cse.mosaic.Mosaic;

public class SierpinskiGasget {
	public static Mosaic gasget(double length) {
		
		
		
		
	}
}
